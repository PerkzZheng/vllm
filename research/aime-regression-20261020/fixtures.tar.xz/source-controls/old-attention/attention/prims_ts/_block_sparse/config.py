# Copyright (c) 2026 by FlashInfer team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Storage-agnostic configuration for PrimTS block-sparse attention."""

from dataclasses import dataclass, replace
import functools
from typing import TYPE_CHECKING, Literal, cast

import torch

from flashinfer.utils import ceil_div

from ..decode import _cutlass_dtype, _dtype_key, _validate_mask, _validate_positive_int
from ..sage import SageAttentionConfig
from .common import (
    _PREPARED_KV_ROUTE_SIZE,
    _SIGNED_INT32_MAX,
    _select_block_sparse_q_tile_size,
    _validate_sparse_kv_block_size,
)
from .prepared import _BlockSparseRouteLayout

if TYPE_CHECKING:
    from ..kernels.fmha_decode.fmha_decode_config import FmhaDecodeConfig


_SUPPORTED_DTYPES = (torch.float16, torch.bfloat16)
# KV128 is the general prepared-route geometry. The qualified Q64/D128
# 16-bit profiles consume one native KV256 route for coarse KV blocks.
_BLOCK_SPARSE_DEFAULT_KV_ROUTE_SIZE = _PREPARED_KV_ROUTE_SIZE
_BLOCK_SPARSE_KV256_ROUTE_SIZE = 256
# CLC work stealing needs roughly two waves of independent sparse rows to
# amortize its request/response path. Below that point, a direct static grid
# avoids scheduler overhead without sacrificing useful device parallelism.
_BLOCK_SPARSE_CLC_MIN_WAVES = 2
_CUDA_GRID_YZ_MAX = 65_535
# Causal CLC needs more work per launch and per row to amortize dequeue cost.
# These B200-qualified thresholds affect scheduling only, not correctness.
_CAUSAL_CLC_WAVE_THRESHOLD = 5
_CAUSAL_CLC_MIN_MAX_ROW_ROUTES = 4
# Fine-Q CLC limits are conservative outside the measured B8/B16 geometries.
_Q8_CONSERVATIVE_CLC_MAX_ROW_ROUTES = 8
_Q8_B8_MASKED_CLC_MAX_ROW_ROUTES = 12
_Q8_FINE_KV_CLC_MAX_QUALIFIED_ROW_ROUTES = 128
# A SWAPAB loop schedules two KV128 route records at a time, padding an odd
# capacity. Representative B200 Q8/B8 and Q16/B16 sweeps place the crossover
# at three pairs for masked B8 and four pairs for B16; unmasked B8 benefits
# immediately. Reuse those measurements as KV-side defaults for every Swaps Q
# tile so cross-geometries do not create additional codegen policy variants.
_B8_MASKED_MIN_PARALLEL_ROUTE_PAIRS = 3
_B16_MIN_PARALLEL_ROUTE_PAIRS = 4


@dataclass(frozen=True)
class _BlockSparseCompileKey:
    """Named, hashable inputs that determine one compiled attention adapter."""

    device_index: int
    batch_size: int
    seq_len_q: int
    seq_len_kv: int
    num_qo_heads: int
    num_kv_heads: int
    head_dim: int
    q_block_size: int
    kv_block_size: int
    kv_route_size: int
    dtype_key: str
    # ``dtype_key`` names Q and K; a Sage plan may resolve other O and V dtypes.
    out_dtype_key: str
    v_dtype_key: str
    mask_type: Literal["dense", "causal"]
    use_kv_valid_bits: bool
    use_persistent_scheduler: bool
    use_parallel_sparse_kv_loads: bool
    sparse_format: Literal["bsr", "bitmask"] = "bsr"
    use_proxy_routes: bool = False
    page_size: int | None = None
    share_pattern_across_kv_heads: bool = False
    # A dense key ignores the routing fields above.
    use_block_sparse: bool = True
    sage: SageAttentionConfig | None = None


@dataclass(frozen=True)
class _BlockSparseLaunchSpec:
    """Resolved launch policy and compile key for one dense or block-sparse plan."""

    policy: tuple[tuple[str, object], ...]
    compile_key: _BlockSparseCompileKey
    # Whether prepared routes carry K32 score-validity words; the decode
    # config owns this rule and the plan sizes its route storage from it.
    prepares_score_words: bool


_CAPACITY_UNSET = object()


@dataclass(frozen=True)
class _BlockSparseStaticProfile:
    """Pure, device-independent facts shared by plan and one-shot paths."""

    batch_size: int
    seq_len_q: int
    seq_len_kv: int
    num_qo_heads: int
    num_kv_heads: int
    head_dim: int
    q_block_size: int
    kv_block_size: int
    q_tile_size: int
    kv_route_size: int
    dtype_key: str
    out_dtype_key: str
    v_dtype_key: str
    q_dtype: torch.dtype
    kv_dtype: torch.dtype
    v_dtype: torch.dtype
    output_dtype: torch.dtype
    mask_type: Literal["dense", "causal"]
    use_kv_valid_bits: bool
    max_blocks_per_row: int | None
    page_size: int | None = None
    share_pattern_across_kv_heads: bool = False
    sage: SageAttentionConfig | None = None
    use_block_sparse: bool = True


def _select_block_sparse_kv_route_size(
    *,
    q_tile_size: int,
    kv_block_size: int,
) -> int:
    """Choose a route width from the immutable compile-time profile."""

    if q_tile_size == 64 and kv_block_size % 64 == 0:
        return _BLOCK_SPARSE_KV256_ROUTE_SIZE
    return _BLOCK_SPARSE_DEFAULT_KV_ROUTE_SIZE


def _should_consider_clc(
    *,
    q_tile_size: int,
    kv_block_size: int,
    mask_type: Literal["dense", "causal"],
    max_row_route_capacity: int,
    use_kv_valid_bits: bool,
) -> bool:
    """Return whether the common selector may choose CLC for this task."""

    if q_tile_size != 8:
        return True
    if mask_type == "causal":
        max_qualified_routes = _Q8_CONSERVATIVE_CLC_MAX_ROW_ROUTES
    elif kv_block_size == 8 and use_kv_valid_bits:
        max_qualified_routes = _Q8_B8_MASKED_CLC_MAX_ROW_ROUTES
    elif kv_block_size in (8, 16):
        max_qualified_routes = _Q8_FINE_KV_CLC_MAX_QUALIFIED_ROW_ROUTES
    else:
        max_qualified_routes = _Q8_CONSERVATIVE_CLC_MAX_ROW_ROUTES
    return max_row_route_capacity <= max_qualified_routes


def _select_parallel_sparse_kv_loads(
    *,
    kv_block_size: int,
    use_kv_valid_bits: bool,
    max_row_route_capacity: int,
    use_persistent_scheduler: bool,
) -> bool:
    """Choose two K/V issuer warps from KV-side TMA issue pressure."""

    if kv_block_size not in (8, 16):
        return False
    if not use_persistent_scheduler:
        return True

    # Base the crossover on paired route capacity so R(2n - 1) and R(2n),
    # whose final pair differs only by one padded route, share one path.
    if kv_block_size == 8 and use_kv_valid_bits:
        min_route_pairs = _B8_MASKED_MIN_PARALLEL_ROUTE_PAIRS
    elif kv_block_size == 16:
        min_route_pairs = _B16_MIN_PARALLEL_ROUTE_PAIRS
    else:
        return True
    route_capacity_pairs = (max_row_route_capacity + 1) // 2
    return route_capacity_pairs >= min_route_pairs


def _select_block_sparse_scheduler(
    *,
    device_index: int,
    batch_size: int,
    seq_len_q: int,
    seq_len_kv: int,
    num_qo_heads: int,
    num_kv_heads: int,
    q_block_size: int,
    kv_block_size: int,
    kv_route_size: int,
    mask_type: Literal["dense", "causal"],
    use_kv_valid_bits: bool,
    max_row_route_capacity: int,
    use_block_sparse: bool,
) -> tuple[int, bool]:
    """Select the Q tile and scheduler without depending on KV storage.

    A dense plan sizes the launch heuristic by the whole K/V sequence.
    Proxy routes add one summary route per row on top of the exact routes and
    see the same per-tile fixed cost the persistent scheduler amortizes, so
    the selection does not depend on the route kind.
    """

    heads_q_per_kv = num_qo_heads // num_kv_heads
    q_tile_size = _select_block_sparse_q_tile_size(
        q_block_size=q_block_size,
        heads_q_per_kv=heads_q_per_kv,
        kv_block_size=kv_block_size,
    )
    launch_args = {
        "device_index": device_index,
        "batch_size": batch_size,
        "seq_len_q": seq_len_q,
        "num_qo_heads": num_qo_heads,
        "num_kv_heads": num_kv_heads,
        "q_tile_size": q_tile_size,
        "kv_route_size": kv_route_size,
    }
    if not use_block_sparse:
        return q_tile_size, _select_persistent_launch(
            seq_len_kv=seq_len_kv, **launch_args
        )
    if not _should_consider_clc(
        q_tile_size=q_tile_size,
        kv_block_size=kv_block_size,
        mask_type=mask_type,
        max_row_route_capacity=max_row_route_capacity,
        use_kv_valid_bits=use_kv_valid_bits,
    ):
        return q_tile_size, False

    return q_tile_size, _select_persistent_launch(
        # Each task is sized by its prepared route capacity, not by the K/V
        # extent.
        seq_len_kv=max_row_route_capacity * kv_route_size,
        persistent_min_waves=(
            _CAUSAL_CLC_WAVE_THRESHOLD
            if mask_type == "causal"
            else _BLOCK_SPARSE_CLC_MIN_WAVES
        ),
        persistent_min_tiles_per_cta=(
            _CAUSAL_CLC_MIN_MAX_ROW_ROUTES if mask_type == "causal" else 1
        ),
        **launch_args,
    )


def _select_persistent_launch(
    *,
    device_index: int,
    batch_size: int,
    seq_len_q: int,
    seq_len_kv: int,
    num_qo_heads: int,
    num_kv_heads: int,
    q_tile_size: int,
    kv_route_size: int,
    persistent_min_waves: int = 1,
    persistent_min_tiles_per_cta: int = 1,
) -> bool:
    """Return whether the decode launch heuristic selects the CLC scheduler.

    ``seq_len_kv`` sizes each task. These plans never split K/V, so any other
    outcome selects the static grid.
    """

    from ..kernels.fmha_decode.fmha_decode_config import (
        _select_auto_launch_mode,
        make_q_tile_geometry,
    )

    q_geometry = make_q_tile_geometry(
        rows_per_cta=q_tile_size,
        heads_q_per_kv=num_qo_heads // num_kv_heads,
        groups_tokens_heads_q=True,
    )
    with torch.cuda.device(device_index):
        mode = _select_auto_launch_mode(
            batch_size=batch_size,
            num_heads_kv=num_kv_heads,
            seq_len_kv=seq_len_kv,
            num_q_tiles=q_geometry.num_q_ctas(seq_len_q),
            tile_size_kv=kv_route_size,
            persistent_min_waves=persistent_min_waves,
            persistent_min_tiles_per_cta=persistent_min_tiles_per_cta,
        )
    return mode == "persistent"


def _validate_dense_contiguous_kv_extent(
    *,
    seq_len_kv: int,
    num_kv_heads: int,
    head_dim: int,
) -> None:
    """Reject a contiguous K/V batch stride the launch ABI cannot express."""

    if seq_len_kv * num_kv_heads * head_dim > _SIGNED_INT32_MAX:
        raise OverflowError(
            "dense contiguous K/V batch stride must fit in signed int32"
        )


def _validate_matching_dtypes(
    q_dtype: torch.dtype,
    kv_dtype: torch.dtype,
    v_dtype: torch.dtype,
    output_dtype: torch.dtype,
) -> str:
    """Validate the 16-bit dtype rule of a plan without Sage attention."""

    if not (q_dtype == kv_dtype == v_dtype == output_dtype):
        raise ValueError("block-sparse requires matching Q, K/V, and output dtypes")
    if q_dtype not in _SUPPORTED_DTYPES:
        raise NotImplementedError(
            "block-sparse supports only torch.float16 and torch.bfloat16"
        )
    return _dtype_key(q_dtype)


def _validate_max_blocks_per_row(
    max_blocks_per_row: int,
    *,
    seq_len_kv: int,
    kv_block_size: int,
) -> int:
    """Validate the required semantic BSR row-capacity declaration."""

    if isinstance(max_blocks_per_row, bool) or not isinstance(max_blocks_per_row, int):
        raise TypeError("max_blocks_per_row must be a Python integer")
    if max_blocks_per_row < 0:
        raise ValueError("max_blocks_per_row must be non-negative")
    num_kv_blocks = ceil_div(seq_len_kv, kv_block_size)
    if max_blocks_per_row > num_kv_blocks:
        raise ValueError(
            "max_blocks_per_row cannot exceed the number of semantic KV blocks "
            f"({num_kv_blocks})"
        )
    return max_blocks_per_row


def _plan_dtype_key(dtype: torch.dtype) -> str:
    """Return the compile-key name of a plan dtype; Int8 is a Sage Q/K dtype."""

    return "int8" if dtype == torch.int8 else _dtype_key(dtype)


def _resolve_plan_dtypes(
    q_dtype: torch.dtype,
    kv_dtype: torch.dtype | None,
    v_dtype: torch.dtype | None,
    output_dtype: torch.dtype | None,
    sage: SageAttentionConfig | None,
) -> tuple[torch.dtype, torch.dtype, torch.dtype, str]:
    """Return ``(kv_dtype, v_dtype, output_dtype, dtype_key)`` of one plan.

    K defaults to Q and V to K. The output defaults to Q, or to bfloat16 with
    Sage; the decode configuration validates the Sage dtype recipe.
    """

    if kv_dtype is None:
        kv_dtype = q_dtype
    if v_dtype is None:
        v_dtype = kv_dtype
    if sage is None:
        if output_dtype is None:
            output_dtype = q_dtype
        return (
            kv_dtype,
            v_dtype,
            output_dtype,
            _validate_matching_dtypes(q_dtype, kv_dtype, v_dtype, output_dtype),
        )
    if not isinstance(sage, SageAttentionConfig):
        raise TypeError("sage must be a SageAttentionConfig instance")
    if q_dtype != kv_dtype:
        raise ValueError("Sage attention requires Q and K in one dtype")
    if output_dtype is None:
        output_dtype = torch.bfloat16
    return kv_dtype, v_dtype, output_dtype, _plan_dtype_key(q_dtype)


def _validate_block_sparse_static_profile(
    *,
    batch_size: int,
    seq_len_q: int,
    seq_len_kv: int,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    q_block_size: int,
    kv_block_size: int,
    use_kv_valid_bits: bool,
    mask_type: Literal["dense", "causal"],
    q_dtype: torch.dtype,
    kv_dtype: torch.dtype | None,
    v_dtype: torch.dtype | None = None,
    output_dtype: torch.dtype | None,
    max_blocks_per_row: object = _CAPACITY_UNSET,
    page_size: int | None = None,
    share_pattern_across_kv_heads: bool = False,
    sage: SageAttentionConfig | None = None,
    use_block_sparse: bool = True,
) -> _BlockSparseStaticProfile:
    """Validate static policy before any device work or BSR inspection."""

    if not isinstance(share_pattern_across_kv_heads, bool):
        raise TypeError("share_pattern_across_kv_heads must be a bool")
    batch_size = _validate_positive_int(batch_size, "batch_size")
    seq_len_q = _validate_positive_int(seq_len_q, "seq_len_q")
    seq_len_kv = _validate_positive_int(seq_len_kv, "seq_len_kv")
    num_qo_heads = _validate_positive_int(num_qo_heads, "num_qo_heads")
    num_kv_heads = _validate_positive_int(num_kv_heads, "num_kv_heads")
    head_dim = _validate_positive_int(head_dim, "head_dim")
    for extent, name in (
        (seq_len_q, "seq_len_q"),
        (seq_len_kv, "seq_len_kv"),
    ):
        if extent > _SIGNED_INT32_MAX:
            raise OverflowError(f"{name} must fit in signed int32")
    # Direct and CLC launches both preserve heads/batch in grid Y/Z.
    for dimension, argument, extent in (
        ("y", "num_kv_heads", num_kv_heads),
        ("z", "batch_size", batch_size),
    ):
        if extent > _CUDA_GRID_YZ_MAX:
            raise ValueError(
                f"block-sparse grid.{dimension} exceeds the CUDA limit "
                f"{_CUDA_GRID_YZ_MAX} ({argument}={extent})"
            )
    if not isinstance(use_kv_valid_bits, bool):
        raise TypeError("use_kv_valid_bits must be a bool")
    kv_block_size = _validate_sparse_kv_block_size(kv_block_size)
    if num_qo_heads % num_kv_heads != 0:
        raise ValueError("num_qo_heads must be divisible by num_kv_heads")
    q_tile_size = _select_block_sparse_q_tile_size(
        q_block_size=q_block_size,
        heads_q_per_kv=num_qo_heads // num_kv_heads,
        kv_block_size=kv_block_size,
    )
    validated_max_blocks_per_row = None
    if max_blocks_per_row is not _CAPACITY_UNSET:
        validated_max_blocks_per_row = _validate_max_blocks_per_row(
            cast(int, max_blocks_per_row),
            seq_len_kv=seq_len_kv,
            kv_block_size=kv_block_size,
        )
    if kv_block_size < 64 and q_tile_size >= 64:
        raise ValueError("fine KV blocks require a SwapsMmaAb Q tile")
    _validate_mask(mask_type)
    if head_dim != 128:
        raise ValueError("block-sparse requires head_dim=128")
    if mask_type == "causal" and seq_len_q > seq_len_kv:
        raise ValueError("causal block-sparse requires seq_len_q <= seq_len_kv")
    kv_dtype, v_dtype, output_dtype, dtype_key = _resolve_plan_dtypes(
        q_dtype, kv_dtype, v_dtype, output_dtype, sage
    )
    kv_route_size = _select_block_sparse_kv_route_size(
        q_tile_size=q_tile_size,
        kv_block_size=kv_block_size,
    )
    if page_size is not None:
        # Validate the paged route geometry with a capacity-free layout; the
        # score-word slots do not take part in the page/atom checks.
        _BlockSparseRouteLayout.create(
            kv_route_size=kv_route_size,
            kv_block_size=kv_block_size,
            page_size=page_size,
            has_token_bits=False,
            route_metadata_capacity=0,
            num_rows=1,
        )
    return _BlockSparseStaticProfile(
        batch_size=batch_size,
        seq_len_q=seq_len_q,
        seq_len_kv=seq_len_kv,
        num_qo_heads=num_qo_heads,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        q_block_size=q_block_size,
        kv_block_size=kv_block_size,
        q_tile_size=q_tile_size,
        kv_route_size=kv_route_size,
        dtype_key=dtype_key,
        out_dtype_key=_plan_dtype_key(output_dtype),
        v_dtype_key=_plan_dtype_key(v_dtype),
        q_dtype=q_dtype,
        kv_dtype=kv_dtype,
        v_dtype=v_dtype,
        output_dtype=output_dtype,
        mask_type=mask_type,
        use_kv_valid_bits=use_kv_valid_bits,
        max_blocks_per_row=validated_max_blocks_per_row,
        page_size=page_size,
        share_pattern_across_kv_heads=share_pattern_across_kv_heads,
        sage=sage,
        use_block_sparse=use_block_sparse,
    )


def _make_block_sparse_config(key: _BlockSparseCompileKey) -> "FmhaDecodeConfig":
    """Build one decode configuration from its exact compile cache key."""

    from ..kernels.fmha_decode.fmha_decode_config import make_decode_config

    dtype = _cutlass_dtype(key.dtype_key)
    out_dtype = _cutlass_dtype(key.out_dtype_key)
    v_dtype = _cutlass_dtype(key.v_dtype_key)
    q_tile_size = _select_block_sparse_q_tile_size(
        q_block_size=key.q_block_size,
        heads_q_per_kv=key.num_qo_heads // key.num_kv_heads,
        kv_block_size=key.kv_block_size,
    )
    use_keeps_mma_ab = q_tile_size >= 64
    config_args: dict[str, object] = {
        "use_keeps_mma_ab": use_keeps_mma_ab,
        "tile_size_q": q_tile_size,
        "tile_size_kv": key.kv_route_size,
        "groups_tokens_heads_q": True,
        "use_block_sparse": key.use_block_sparse,
    }
    if key.use_block_sparse:
        config_args.update(
            {
                "q_block_size": key.q_block_size,
                "kv_block_size": key.kv_block_size,
                "use_kv_valid_bits": key.use_kv_valid_bits,
                "use_parallel_sparse_kv_loads": key.use_parallel_sparse_kv_loads,
                "share_pattern_across_kv_heads": key.share_pattern_across_kv_heads,
            }
        )
        if key.use_proxy_routes:
            config_args["use_block_sparse_proxy_routes"] = True
    if key.use_persistent_scheduler:
        config_args["use_persistent_scheduler"] = True
    if key.sage is not None:
        config_args.update(
            {
                "sage_q_block_size": key.sage.q_block_size,
                "sage_k_block_size": key.sage.k_block_size,
                "sage_k_summary_block_size": (
                    key.sage.k_summary_block_size
                    if key.use_proxy_routes
                    else key.sage.k_block_size
                ),
                "sage_v_mean": key.sage.v_mean,
            }
        )
    layout_args: dict[str, object]
    if key.page_size is None:
        layout_args = {"qkv_layout": "contiguousKv"}
    else:
        layout_args = {
            "qkv_layout": "pagedKv",
            "num_tokens_per_page": key.page_size,
        }
    return make_decode_config(
        headdim=key.head_dim,
        args=config_args,
        seq_len_q=key.seq_len_q,
        seq_len_kv=key.seq_len_kv,
        batch_size=key.batch_size,
        num_heads_q=key.num_qo_heads,
        num_heads_kv=key.num_kv_heads,
        q_dtype=dtype,
        k_dtype=dtype,
        v_dtype=v_dtype,
        o_dtype=out_dtype,
        split_kv_mode="disabled",
        splits_kv=1,
        split_kv=False,
        mask_type=key.mask_type,
        auto_tuner=False,
        **layout_args,
    )


@functools.cache
def _resolve_block_sparse_launch_spec(
    device_index: int,
    batch_size: int,
    seq_len_q: int,
    seq_len_kv: int,
    num_qo_heads: int,
    num_kv_heads: int,
    head_dim: int,
    q_block_size: int,
    kv_block_size: int,
    kv_route_size: int,
    dtype_key: str,
    mask_type: Literal["dense", "causal"],
    use_kv_valid_bits: bool,
    max_row_route_capacity: int,
    sparse_format: Literal["bsr", "bitmask"] = "bsr",
    use_proxy_routes: bool = False,
    page_size: int | None = None,
    share_pattern_across_kv_heads: bool = False,
    *,
    use_block_sparse: bool = True,
    out_dtype_key: str,
    v_dtype_key: str,
    sage: SageAttentionConfig | None = None,
) -> _BlockSparseLaunchSpec:
    """Resolve and cache one validated static or CLC launch.

    ``max_row_route_capacity`` is a conservative prepared-route bound. Live
    index values and physical-tail morphology never specialize this cache
    entry. Proxy and exact routes share one scheduler selection. An
    unsupported persistent profile falls back to its valid static
    counterpart.
    """

    q_tile_size, use_persistent_scheduler = _select_block_sparse_scheduler(
        device_index=device_index,
        batch_size=batch_size,
        seq_len_q=seq_len_q,
        seq_len_kv=seq_len_kv,
        num_qo_heads=num_qo_heads,
        num_kv_heads=num_kv_heads,
        q_block_size=q_block_size,
        kv_block_size=kv_block_size,
        kv_route_size=kv_route_size,
        mask_type=mask_type,
        use_kv_valid_bits=use_kv_valid_bits,
        max_row_route_capacity=max_row_route_capacity,
        use_block_sparse=use_block_sparse,
    )
    if not use_block_sparse:
        _validate_dense_contiguous_kv_extent(
            seq_len_kv=seq_len_kv,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
        )

    def parallel_loads(persistent: bool) -> bool:
        return use_block_sparse and _select_parallel_sparse_kv_loads(
            kv_block_size=kv_block_size,
            use_kv_valid_bits=use_kv_valid_bits,
            max_row_route_capacity=max_row_route_capacity,
            use_persistent_scheduler=persistent,
        )

    compile_key = _BlockSparseCompileKey(
        device_index=device_index,
        batch_size=batch_size,
        seq_len_q=seq_len_q,
        seq_len_kv=seq_len_kv,
        num_qo_heads=num_qo_heads,
        num_kv_heads=num_kv_heads,
        head_dim=head_dim,
        q_block_size=q_block_size,
        kv_block_size=kv_block_size,
        kv_route_size=kv_route_size,
        dtype_key=dtype_key,
        mask_type=mask_type,
        use_kv_valid_bits=use_kv_valid_bits,
        use_persistent_scheduler=use_persistent_scheduler,
        use_parallel_sparse_kv_loads=parallel_loads(use_persistent_scheduler),
        sparse_format=sparse_format,
        use_proxy_routes=use_proxy_routes,
        page_size=page_size,
        use_block_sparse=use_block_sparse,
        share_pattern_across_kv_heads=share_pattern_across_kv_heads,
        out_dtype_key=out_dtype_key,
        v_dtype_key=v_dtype_key,
        sage=sage,
    )
    try:
        config = _make_block_sparse_config(compile_key)
    except ValueError:
        if not compile_key.use_persistent_scheduler:
            raise
        compile_key = replace(
            compile_key,
            use_persistent_scheduler=False,
            use_parallel_sparse_kv_loads=parallel_loads(False),
        )
        config = _make_block_sparse_config(compile_key)

    if compile_key.sage is not None:
        # Key by the resolved summary block so equivalent recipes share one
        # adapter.
        compile_key = replace(
            compile_key,
            sage=replace(
                compile_key.sage,
                k_summary_block_size=config.sage_k_summary_block_size,
            ),
        )

    policy_entries: list[tuple[str, object]] = [
        ("tile_size_q", q_tile_size),
        ("tile_size_kv", kv_route_size),
        (
            "scheduler",
            "persistent" if compile_key.use_persistent_scheduler else "static",
        ),
    ]
    if page_size is not None:
        policy_entries.append(("page_size", page_size))
    policy_entries.extend(
        (
            ("use_persistent_scheduler", compile_key.use_persistent_scheduler),
            ("max_row_route_capacity", max_row_route_capacity),
            ("use_kv_valid_bits", use_kv_valid_bits),
            (
                "use_parallel_sparse_kv_loads",
                compile_key.use_parallel_sparse_kv_loads,
            ),
        )
    )
    return _BlockSparseLaunchSpec(
        policy=tuple(policy_entries),
        compile_key=compile_key,
        prepares_score_words=config.uses_prepared_score_keep_words,
    )


__all__ = [
    "_BlockSparseCompileKey",
    "_BlockSparseLaunchSpec",
    "_BlockSparseStaticProfile",
    "_make_block_sparse_config",
    "_resolve_block_sparse_launch_spec",
    "_select_block_sparse_kv_route_size",
    "_select_parallel_sparse_kv_loads",
    "_select_persistent_launch",
    "_should_consider_clc",
    "_validate_block_sparse_static_profile",
    "_validate_dense_contiguous_kv_extent",
    "_validate_matching_dtypes",
    "_validate_max_blocks_per_row",
]
