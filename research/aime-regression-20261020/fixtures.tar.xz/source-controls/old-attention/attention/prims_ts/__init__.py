# Copyright (c) 2026 by FlashInfer team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Experimental task-scheduled attention entry points."""

from .block_sparse import (
    BlockSparsePagedTSWrapper,
    BlockSparseTSWrapper,
    block_sparse_attention,
    block_sparse_attention_with_paged_kv_cache,
)
from .decode import (
    BatchDecodePagedTSWrapper,
    PrimsTSBatchDecodePlan,
    batch_decode_with_paged_kv_cache,
    get_prims_ts_batch_decode_workspace_size,
    make_q_token_kv_block_sparse_qo_indptr,
    prepare_prims_ts_batch_decode_with_kv_cache,
    suggest_q_token_kv_block_sparse_group_size,
    validate_q_token_kv_block_sparse_group_size,
)
from .context import (
    BatchPrefillPagedTSWrapper,
    BatchPrefillTSWrapper,
    batch_prefill,
    batch_prefill_with_paged_kv_cache,
)
from .mla_decode import (
    BatchSparseMLADecodePagedTSWrapper,
    SparseMLAPreparedMetadata,
    batch_sparse_mla_decode_with_paged_kv_cache,
    get_prims_ts_sparse_mla_decode_workspace_size,
    BatchMLADecodePagedTSWrapper,
    batch_mla_decode_with_paged_kv_cache,
    get_prims_ts_batch_mla_decode_workspace_size,
)
from .q_token_kv_block_sparse_metadata import (
    QTokenKvBlockSparsePagedTSWrapper,
    get_q_token_kv_block_sparse_workspace_size,
    q_token_kv_block_sparse_attention_with_paged_kv_cache,
)
from .sage import SageAttentionConfig, SageAttentionParams

__all__ = [
    "SparseMLAPreparedMetadata",
    "BatchSparseMLADecodePagedTSWrapper",
    "batch_sparse_mla_decode_with_paged_kv_cache",
    "get_prims_ts_sparse_mla_decode_workspace_size",
    "BlockSparseTSWrapper",
    "SageAttentionConfig",
    "SageAttentionParams",
    "BlockSparsePagedTSWrapper",
    "block_sparse_attention",
    "block_sparse_attention_with_paged_kv_cache",
    "BatchPrefillTSWrapper",
    "BatchPrefillPagedTSWrapper",
    "batch_prefill",
    "batch_prefill_with_paged_kv_cache",
    "BatchDecodePagedTSWrapper",
    "PrimsTSBatchDecodePlan",
    "batch_decode_with_paged_kv_cache",
    "get_prims_ts_batch_decode_workspace_size",
    "make_q_token_kv_block_sparse_qo_indptr",
    "prepare_prims_ts_batch_decode_with_kv_cache",
    "suggest_q_token_kv_block_sparse_group_size",
    "validate_q_token_kv_block_sparse_group_size",
    "QTokenKvBlockSparsePagedTSWrapper",
    "get_q_token_kv_block_sparse_workspace_size",
    "q_token_kv_block_sparse_attention_with_paged_kv_cache",
    "BatchMLADecodePagedTSWrapper",
    "batch_mla_decode_with_paged_kv_cache",
    "get_prims_ts_batch_mla_decode_workspace_size",
]
